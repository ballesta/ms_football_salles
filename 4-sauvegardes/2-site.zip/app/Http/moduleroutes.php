<?php
        Route::controller('reseauxsalles', 'ReseauxsallesController');
                    Route::controller('complexesportif', 'ComplexesportifController');
                    Route::controller('malette', 'MaletteController');
                    Route::controller('capteur', 'CapteurController');
                    Route::controller('salle', 'SalleController');
                    Route::controller('equipe', 'EquipeController');
                    Route::controller('joueur', 'JoueurController');
                    Route::controller('partie', 'PartieController');
                    Route::controller('joueurselectionne', 'JoueurselectionneController');
                    Route::controller('sessionmesure', 'SessionmesureController');
                    Route::controller('mesure', 'MesureController');
                    Route::controller('mesurestoutes', 'MesurestoutesController');
                    Route::controller('joueursComplexe', 'JoueursComplexeController');
                    Route::controller('joueurCentre', 'JoueurCentreController');
                    ?>