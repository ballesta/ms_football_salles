<?php 
define('CNF_APPNAME','MS Football');
define('CNF_APPDESC','PHP Application Builder and Platform IDE');
define('CNF_COMNAME','MS Football');
define('CNF_EMAIL','bernard@ballesta.fr');
define('CNF_METAKEY','my site , my company  , Larvel Crud');
define('CNF_METADESC','Write description for your site');
define('CNF_GROUP','3');
define('CNF_ACTIVATION','confirmation');
define('CNF_MULTILANG','0'); //bb
define('CNF_LANG','fr'); //bb
define('CNF_REGIST','true');
define('CNF_FRONT','true');
define('CNF_RECAPTCHA','false');
define('CNF_THEME','sximone');
define('CNF_RECAPTCHAPUBLICKEY','');
define('CNF_RECAPTCHAPRIVATEKEY','');
define('CNF_MODE','production');
define('CNF_LOGO','backend-logo.png');
?>