
-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `payload` text,
  `last_activity` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('5f50febd6f9c8e4051d83d93af7725448e555aab', 'YToxODp7czo2OiJfdG9rZW4iO3M6NDA6Ikt1d0hQTHNuQzBnelgxWm4yVE9LNVBpaFZnMUxIRzJyaFVJcjZNWk4iO3M6Mzg6ImxvZ2luXzgyZTVkMmM1NmJkZDA4MTEzMThmMGNmMDc4Yjc4YmZjIjtpOjU7czozOiJ1aWQiO2k6NTtzOjM6ImdpZCI7aToxO3M6MzoiZWlkIjtzOjE5OiJiZXJuYXJkQGJhbGxlc3RhLmZyIjtzOjI6ImxsIjtzOjE5OiIyMDE2LTEwLTA1IDE4OjA2OjMzIjtzOjM6ImZpZCI7czoxNjoiQmVybmFyZCBCQUxMRVNUQSI7czo2OiJ0aGVtZXMiO3M6MTY6InN4aW1vLWxpZ2h0LWJsdWUiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQ5OiJodHRwOi8vbXMtZm9vdGJhbGwtc2FsbGVzLzItc2l0ZS9wdWJsaWMvZGFzaGJvYXJkIjt9czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjQ6ImxhbmciO3M6MjoiZnIiO3M6NzoiY2x1Yl9pZCI7czoxOiIzIjtzOjE3OiJjb21wbGV4ZV9zYWxsZV9pZCI7czoxOiIxIjtzOjg6InNhbGxlX2lkIjtzOjE6IjEiO3M6OToicGFydGllX2lkIjtzOjE6IjIiO3M6OToiZXF1aXBlX2lkIjtzOjE6IjIiO3M6MjI6IlBIUERFQlVHQkFSX1NUQUNLX0RBVEEiO2E6MDp7fXM6OToiX3NmMl9tZXRhIjthOjM6e3M6MToidSI7aToxNDc2MjAxMjAwO3M6MToiYyI7aToxNDc2MTg4NjA0O3M6MToibCI7czoxOiIwIjt9fQ==', 1476201200);
