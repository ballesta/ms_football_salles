
-- --------------------------------------------------------

--
-- Structure de la table `fbs_reseaux_salles`
--

CREATE TABLE `fbs_reseaux_salles` (
  `club_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `ville` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fbs_reseaux_salles`
--

INSERT INTO `fbs_reseaux_salles` (`club_id`, `nom`, `ville`) VALUES
(3, 'Urban Soccer', 'Paris'),
(4, 'Bubble Socer Arena', 'Boissy Saint Leger');
