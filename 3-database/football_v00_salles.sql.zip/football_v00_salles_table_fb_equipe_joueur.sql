
-- --------------------------------------------------------

--
-- Structure de la table `fb_equipe_joueur`
--

CREATE TABLE `fb_equipe_joueur` (
  `equipe_joueur_id` int(10) UNSIGNED NOT NULL,
  `equipe_id` int(10) UNSIGNED NOT NULL,
  `joueur_id` int(10) UNSIGNED NOT NULL,
  `club_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_equipe_joueur`
--

INSERT INTO `fb_equipe_joueur` (`equipe_joueur_id`, `equipe_id`, `joueur_id`, `club_id`) VALUES
(7, 2, 5, 1),
(6, 1, 4, 1);
