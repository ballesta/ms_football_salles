
-- --------------------------------------------------------

--
-- Structure de la table `fbs_salles`
--

CREATE TABLE `fbs_salles` (
  `salle_id` int(11) NOT NULL,
  `identifiant` varchar(20) NOT NULL,
  `complexe_salle_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fbs_salles`
--

INSERT INTO `fbs_salles` (`salle_id`, `identifiant`, `complexe_salle_id`) VALUES
(1, '1', 1),
(2, '2', 1),
(3, '3', 1),
(4, '4', 1),
(5, '5', 1),
(6, '6', 1),
(7, '7', 1),
(8, '8', 1),
(9, '9', 1),
(10, '10', 1);
