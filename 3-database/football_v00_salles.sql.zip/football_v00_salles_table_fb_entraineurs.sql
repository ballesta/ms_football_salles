
-- --------------------------------------------------------

--
-- Structure de la table `fb_entraineurs`
--

CREATE TABLE `fb_entraineurs` (
  `entraineur_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `club_id` int(10) UNSIGNED NOT NULL,
  `tb_users_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_entraineurs`
--

INSERT INTO `fb_entraineurs` (`entraineur_id`, `nom`, `prenom`, `club_id`, `tb_users_id`) VALUES
(6, 'Unai', 'Emery', 1, 0);
