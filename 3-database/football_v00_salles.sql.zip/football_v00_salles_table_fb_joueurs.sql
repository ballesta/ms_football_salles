
-- --------------------------------------------------------

--
-- Structure de la table `fb_joueurs`
--

CREATE TABLE `fb_joueurs` (
  `joueur_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `premon` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `taille` double(8,2) DEFAULT NULL,
  `poids` double(8,2) DEFAULT NULL,
  `poste_id` int(10) UNSIGNED DEFAULT NULL,
  `complexe_salle_id` int(10) UNSIGNED NOT NULL,
  `equipe_id` int(10) UNSIGNED DEFAULT NULL,
  `categorie_id` int(10) UNSIGNED DEFAULT NULL,
  `entraineur_id` int(10) UNSIGNED DEFAULT NULL,
  `tb_users_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_joueurs`
--

INSERT INTO `fb_joueurs` (`joueur_id`, `nom`, `premon`, `date_naissance`, `taille`, `poids`, `poste_id`, `complexe_salle_id`, `equipe_id`, `categorie_id`, `entraineur_id`, `tb_users_id`) VALUES
(4, 'Ibrahimovitch', 'Slatan', '1988-01-01', 199.00, 99.00, 1, 1, 1, 5, 6, 0),
(5, 'TRAPP', 'Kevin', '1980-01-01', 188.00, 88.00, 4, 1, 1, 5, 6, 0),
(6, 'Platini', 'Michel', NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, NULL);
