
-- --------------------------------------------------------

--
-- Structure de la table `fb_clubs`
--

CREATE TABLE `fb_clubs` (
  `club_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `ville` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_clubs`
--

INSERT INTO `fb_clubs` (`club_id`, `nom`, `ville`) VALUES
(1, 'Paris Saint-Germain', 'Paris'),
(2, 'Five FC', 'Paris'),
(3, 'Urban Soccer', 'Ivry');
