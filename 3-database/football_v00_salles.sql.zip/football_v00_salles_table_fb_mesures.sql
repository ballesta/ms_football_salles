
-- --------------------------------------------------------

--
-- Structure de la table `fb_mesures`
--

CREATE TABLE `fb_mesures` (
  `mesure_id` int(10) UNSIGNED NOT NULL,
  `activite_tps_total` double(8,2) NOT NULL,
  `id_capteur` int(11) DEFAULT NULL,
  `chrono_secondes` double(8,2) DEFAULT NULL,
  `type` enum('STEP','SHOOT','PASS') COLLATE utf8_unicode_ci DEFAULT NULL,
  `vitesse` double(8,2) DEFAULT NULL,
  `distance` double(8,2) DEFAULT NULL,
  `distance_totale` double(8,2) DEFAULT NULL,
  `club_id` int(10) UNSIGNED NOT NULL,
  `session_mesure_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_mesures`
--

INSERT INTO `fb_mesures` (`mesure_id`, `activite_tps_total`, `id_capteur`, `chrono_secondes`, `type`, `vitesse`, `distance`, `distance_totale`, `club_id`, `session_mesure_id`) VALUES
(3, 11.00, 1, 11.00, 'SHOOT', 11.00, 11.00, 11.00, 1, 4);
