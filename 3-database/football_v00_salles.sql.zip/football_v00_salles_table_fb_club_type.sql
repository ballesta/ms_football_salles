
-- --------------------------------------------------------

--
-- Structure de la table `fb_club_type`
--

CREATE TABLE `fb_club_type` (
  `club_type_id` int(10) UNSIGNED NOT NULL,
  `type_club` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
