
-- --------------------------------------------------------

--
-- Structure de la table `fb_capteurs`
--

CREATE TABLE `fb_capteurs` (
  `capteur_id` int(10) UNSIGNED NOT NULL,
  `numero_serie` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `date_achat` date NOT NULL,
  `club_id` int(10) UNSIGNED DEFAULT NULL,
  `malette_capteurs_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_capteurs`
--

INSERT INTO `fb_capteurs` (`capteur_id`, `numero_serie`, `date_achat`, `club_id`, `malette_capteurs_id`) VALUES
(1, '123456789', '2016-01-02', 1, 0),
(2, '987654321', '0000-00-00', 1, 0),
(3, '1111111111', '2016-10-02', NULL, 6),
(4, '222222222222222222', '2016-10-10', NULL, 6),
(5, '33333333333333333', '2016-10-10', NULL, 9);
