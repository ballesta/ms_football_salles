
-- --------------------------------------------------------

--
-- Structure de la table `tb_menu`
--

CREATE TABLE `tb_menu` (
  `menu_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `menu_name` varchar(100) DEFAULT NULL,
  `menu_type` char(10) DEFAULT NULL,
  `role_id` varchar(100) DEFAULT NULL,
  `deep` smallint(2) DEFAULT NULL,
  `ordering` int(6) DEFAULT NULL,
  `position` enum('top','sidebar','both') DEFAULT NULL,
  `menu_icons` varchar(30) DEFAULT NULL,
  `active` enum('0','1') DEFAULT '1',
  `access_data` text,
  `allow_guest` enum('0','1') DEFAULT '0',
  `menu_lang` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tb_menu`
--

INSERT INTO `tb_menu` (`menu_id`, `parent_id`, `module`, `url`, `menu_name`, `menu_type`, `role_id`, `deep`, `ordering`, `position`, `menu_icons`, `active`, `access_data`, `allow_guest`, `menu_lang`) VALUES
(2, 0, 'contact-us', '', 'Contact Us', 'internal', NULL, NULL, 2, 'top', '', '1', '{"1":"0","2":"0","3":"0"}', '1', NULL),
(12, 0, 'about-us', '', 'About', 'internal', NULL, NULL, 0, 'top', '', '1', '{"1":"0","2":"0","3":"0"}', '1', NULL),
(13, 0, 'service', '', 'Service', 'internal', NULL, NULL, 1, 'top', '', '1', '{"1":"0","2":"0","3":"0"}', '1', '{"title":{"id":""}}'),
(17, 0, 'reseauxsalles', NULL, 'Sport installations network', 'internal', NULL, NULL, 0, 'sidebar', 'icon-pyramid', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"R\\u00e9seaux de salles de football"}}'),
(18, 0, 'complexesportif', NULL, 'Sports Complex', 'internal', NULL, NULL, 1, 'sidebar', 'icon-windows8', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"Complexe sportif"}}'),
(19, 0, 'malette', NULL, 'Sensor box', 'internal', NULL, NULL, 6, 'sidebar', 'icon-table2', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"Malettes de capteurs"}}'),
(20, 0, 'capteur', NULL, 'Sensors', 'internal', NULL, NULL, 7, 'sidebar', 'icon-arrow-right12', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"Capteurs"}}'),
(21, 0, 'salle', NULL, 'Soccer indoor rooms', 'internal', NULL, NULL, 2, 'sidebar', 'icon-link22', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"Salles de football"}}'),
(22, 0, 'equipe', NULL, 'Teams', 'internal', NULL, NULL, 3, 'sidebar', 'icon-users', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"Equipes"}}'),
(23, 0, 'joueur', NULL, 'Players', 'internal', NULL, NULL, 4, 'sidebar', 'icon-user', '1', '{"1":"1","2":"1","3":"1"}', '1', '{"title":{"fr":"Joueurs"}}'),
(24, 0, 'partie', NULL, 'Matchs', 'internal', NULL, NULL, 5, 'sidebar', 'icon-stopwatch', '1', '{"1":"1","2":"1","3":"1"}', NULL, '{"title":{"fr":"Parties"}}');
