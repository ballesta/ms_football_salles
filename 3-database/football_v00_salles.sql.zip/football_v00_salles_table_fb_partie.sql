
-- --------------------------------------------------------

--
-- Structure de la table `fb_partie`
--

CREATE TABLE `fb_partie` (
  `partie_id` int(10) UNSIGNED NOT NULL,
  `debut` datetime NOT NULL,
  `duree` int(11) DEFAULT NULL,
  `salle_id` int(10) UNSIGNED NOT NULL,
  `equipe_id` int(11) UNSIGNED NOT NULL,
  `malette_capteurs_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_partie`
--

INSERT INTO `fb_partie` (`partie_id`, `debut`, `duree`, `salle_id`, `equipe_id`, `malette_capteurs_id`) VALUES
(2, '2016-08-15 14:00:34', NULL, 1, 1, 9),
(3, '2016-08-12 14:00:51', NULL, 1, 2, 3),
(4, '2016-11-01 12:15:48', NULL, 1, 1, 9);
