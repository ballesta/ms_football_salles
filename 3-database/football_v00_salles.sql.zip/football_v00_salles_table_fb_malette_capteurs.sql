
-- --------------------------------------------------------

--
-- Structure de la table `fb_malette_capteurs`
--

CREATE TABLE `fb_malette_capteurs` (
  `malette_capteurs_id` int(10) UNSIGNED NOT NULL,
  `identifiant` varchar(10) NOT NULL,
  `complexe_salle_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_malette_capteurs`
--

INSERT INTO `fb_malette_capteurs` (`malette_capteurs_id`, `identifiant`, `complexe_salle_id`) VALUES
(9, 'A', 1),
(3, 'B', 2),
(8, 'D', 1),
(5, 'A', 2),
(6, 'B', 1),
(7, 'C', 1);
