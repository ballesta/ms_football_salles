
-- --------------------------------------------------------

--
-- Structure de la table `fb_joueurs_selectionnes`
--

CREATE TABLE `fb_joueurs_selectionnes` (
  `joueur_selectionne_id` int(10) UNSIGNED NOT NULL,
  `partie_id` int(10) UNSIGNED NOT NULL,
  `joueur_id` int(10) UNSIGNED NOT NULL,
  `capteur_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_joueurs_selectionnes`
--

INSERT INTO `fb_joueurs_selectionnes` (`joueur_selectionne_id`, `partie_id`, `joueur_id`, `capteur_id`) VALUES
(1, 2, 4, 1),
(2, 2, 5, 3),
(3, 2, 6, 4);
