
-- --------------------------------------------------------

--
-- Structure de la table `tb_pages`
--

CREATE TABLE `tb_pages` (
  `pageID` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(100) DEFAULT NULL,
  `note` text,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `status` enum('enable','disable') DEFAULT 'enable',
  `access` text,
  `allow_guest` enum('0','1') DEFAULT '0',
  `template` enum('frontend','backend') DEFAULT 'frontend',
  `metakey` varchar(255) DEFAULT NULL,
  `metadesc` text,
  `default` enum('0','1') DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tb_pages`
--

INSERT INTO `tb_pages` (`pageID`, `title`, `alias`, `note`, `created`, `updated`, `filename`, `status`, `access`, `allow_guest`, `template`, `metakey`, `metadesc`, `default`) VALUES
(1, 'Homepage', 'home', NULL, '2014-02-14 00:00:00', '2014-02-14 00:00:00', 'home', 'enable', '{"1":"1","2":"1","3":"1"}', '1', 'frontend', 'tet', 'tetet', '1'),
(29, 'service', 'service', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'service', 'enable', '{"1":"1","2":"0","3":"0"}', '1', 'frontend', '', '', '0'),
(27, 'About Us', 'about-us', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'aboutus', 'enable', '{"1":"1","2":"0","3":"0"}', '1', 'frontend', '', '', '0'),
(26, 'Contact Us', 'contact-us', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'contactus', 'enable', '{"1":"1","2":"0","3":"0"}', '1', 'frontend', '', '', ''),
(46, 'Privacy Policy', 'privacy', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'privacy', 'enable', '{"1":"1","2":"0","3":"0"}', '1', 'frontend', '', '', ''),
(45, 'Term Of Condition', 'toc', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'toc', 'enable', '{"1":"1","2":"0","3":"0"}', '1', 'frontend', '', '', ''),
(47, 'Sample Page Backend', 'backend', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'backend', 'enable', '{"1":"1","2":"0","3":"0"}', '1', 'backend', '', '', '');
