
-- --------------------------------------------------------

--
-- Structure de la table `fb_stades`
--

CREATE TABLE `fb_stades` (
  `stade_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL,
  `club_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_stades`
--

INSERT INTO `fb_stades` (`stade_id`, `nom`, `club_id`) VALUES
(1, 'Parc des princes', 1),
(2, 'Stade de france', 1);
