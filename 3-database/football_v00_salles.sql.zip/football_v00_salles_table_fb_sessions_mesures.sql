
-- --------------------------------------------------------

--
-- Structure de la table `fb_sessions_mesures`
--

CREATE TABLE `fb_sessions_mesures` (
  `session_mesure_id` int(10) UNSIGNED NOT NULL,
  `date_heure` datetime DEFAULT NULL,
  `activite_temps_total` double(8,2) DEFAULT NULL,
  `activite_distance` double(8,2) DEFAULT NULL,
  `activite_vitesse_moyenne` double(8,2) DEFAULT NULL,
  `marche_temps_total` double(8,2) DEFAULT NULL,
  `marche_distance` double(8,2) DEFAULT NULL,
  `marche_vitesse_moyenne` double(8,2) DEFAULT NULL,
  `course_temps_total` double(8,2) DEFAULT NULL,
  `course_distance` double(8,2) DEFAULT NULL,
  `course_vitesse_moyenne` double(8,2) DEFAULT NULL,
  `sprint_temps_total` double(8,2) DEFAULT NULL,
  `sprint_distance` double(8,2) DEFAULT NULL,
  `sprint_vitesse_moyenne` double(8,2) DEFAULT NULL,
  `sprint_vitesse_maximum` double(8,2) DEFAULT NULL,
  `club_id` int(10) UNSIGNED DEFAULT NULL,
  `activite_id` int(10) UNSIGNED DEFAULT NULL,
  `capteur_id` int(10) UNSIGNED NOT NULL,
  `joueur_id` int(10) UNSIGNED NOT NULL,
  `entraineur_id` int(10) UNSIGNED DEFAULT NULL,
  `joueur_selectionne_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fb_sessions_mesures`
--

INSERT INTO `fb_sessions_mesures` (`session_mesure_id`, `date_heure`, `activite_temps_total`, `activite_distance`, `activite_vitesse_moyenne`, `marche_temps_total`, `marche_distance`, `marche_vitesse_moyenne`, `course_temps_total`, `course_distance`, `course_vitesse_moyenne`, `sprint_temps_total`, `sprint_distance`, `sprint_vitesse_moyenne`, `sprint_vitesse_maximum`, `club_id`, `activite_id`, `capteur_id`, `joueur_id`, `entraineur_id`, `joueur_selectionne_id`) VALUES
(4, '2016-08-12 19:35:55', 1.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 1, 2, 1, 4, NULL, NULL);
