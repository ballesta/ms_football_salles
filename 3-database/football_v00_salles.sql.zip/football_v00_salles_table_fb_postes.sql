
-- --------------------------------------------------------

--
-- Structure de la table `fb_postes`
--

CREATE TABLE `fb_postes` (
  `poste_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_postes`
--

INSERT INTO `fb_postes` (`poste_id`, `nom`) VALUES
(1, 'Attaquant'),
(2, 'Défenseur'),
(3, 'Milieu de terrain'),
(4, 'Gardien de but');
