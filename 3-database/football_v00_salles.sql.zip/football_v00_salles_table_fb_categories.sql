
-- --------------------------------------------------------

--
-- Structure de la table `fb_categories`
--

CREATE TABLE `fb_categories` (
  `categorie_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL,
  `description` text NOT NULL,
  `entraineur_id` int(10) UNSIGNED NOT NULL,
  `club_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_categories`
--

INSERT INTO `fb_categories` (`categorie_id`, `nom`, `description`, `entraineur_id`, `club_id`) VALUES
(2, 'U19', 'Moins de 19 ans', 6, 1),
(5, 'Senior', '<p>Plus de 19 ans<br></p>', 6, 1),
(11, 'U20', 'Moins de 20 ans', 6, 1);
