
-- --------------------------------------------------------

--
-- Structure de la table `tb_logs`
--

CREATE TABLE `tb_logs` (
  `auditID` int(20) NOT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `task` varchar(50) DEFAULT NULL,
  `note` text,
  `logdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tb_logs`
--

INSERT INTO `tb_logs` (`auditID`, `ipaddress`, `user_id`, `module`, `task`, `note`, `logdate`) VALUES
(1, '::1', 5, 'reseauxsalles', 'save', 'New Data with ID 4 Has been Inserted !', '2016-09-26 11:24:03'),
(2, '::1', 5, 'complexesportif', 'save', 'New Data with ID 1 Has been Inserted !', '2016-09-27 15:24:08'),
(3, '::1', 5, 'complexesportif', 'save', 'New Data with ID 2 Has been Inserted !', '2016-09-27 15:24:39'),
(4, '::1', 5, 'complexesportif', 'save', 'New Data with ID 3 Has been Inserted !', '2016-09-27 22:13:06'),
(5, '::1', 5, 'complexesportif', 'save', 'New Data with ID 4 Has been Inserted !', '2016-09-28 19:10:28'),
(6, '::1', 5, 'complexesportif', 'save', 'Data with ID 4 Has been Updated !', '2016-09-28 22:16:45'),
(7, '::1', 5, 'complexesportif', 'save', 'Data with ID 1 Has been Updated !', '2016-10-06 14:43:50'),
(8, '::1', 5, 'complexesportif', 'save', 'Data with ID 3 Has been Updated !', '2016-10-06 14:44:39'),
(9, '::1', 5, 'complexesportif', 'save', 'Data with ID 3 Has been Updated !', '2016-10-06 14:44:43'),
(10, '::1', 5, 'complexesportif', 'save', 'Data with ID 2 Has been Updated !', '2016-10-06 14:44:57'),
(11, '::1', 5, 'complexesportif', 'save', 'Data with ID 4 Has been Updated !', '2016-10-06 14:45:11'),
(12, '::1', 5, 'complexesportif', 'save', 'Data with ID 2 Has been Updated !', '2016-10-06 14:51:38'),
(13, '::1', 5, 'complexesportif', 'save', 'Data with ID 2 Has been Updated !', '2016-10-06 14:54:31'),
(14, '::1', 5, 'complexesportif', 'save', 'New Data with ID 5 Has been Inserted !', '2016-10-06 14:56:18'),
(15, '::1', 5, 'complexesportif', 'delete', 'ID : 5  , Has Been Removed Successfull', '2016-10-06 14:56:27'),
(16, '::1', 5, 'malette', 'save', 'New Data with ID 1 Has been Inserted !', '2016-10-06 15:14:06'),
(17, '::1', 5, 'malette', 'save', 'New Data with ID 2 Has been Inserted !', '2016-10-06 15:16:02'),
(18, '::1', 5, 'malette', 'save', 'New Data with ID 3 Has been Inserted !', '2016-10-06 15:17:45'),
(19, '::1', 5, 'malette', 'save', 'New Data with ID 4 Has been Inserted !', '2016-10-06 15:19:33'),
(20, '::1', 5, 'malette', 'save', 'New Data with ID 5 Has been Inserted !', '2016-10-06 15:30:41'),
(21, '::1', 5, 'malette', 'save', 'New Data with ID 6 Has been Inserted !', '2016-10-06 15:33:19'),
(22, '::1', 5, 'malette', 'save', 'New Data with ID 7 Has been Inserted !', '2016-10-06 15:34:20'),
(23, '::1', 5, 'malette', 'delete', 'ID : 1,2,4  , Has Been Removed Successfull', '2016-10-06 15:35:16'),
(24, '::1', 5, 'malette', 'save', 'New Data with ID 8 Has been Inserted !', '2016-10-06 15:37:02'),
(25, '::1', 5, 'malette', 'save', 'New Data with ID 9 Has been Inserted !', '2016-10-06 15:40:58'),
(26, '::1', 5, 'malette', 'save', 'New Data with ID 10 Has been Inserted !', '2016-10-06 15:41:21'),
(27, '::1', 5, 'malette', 'delete', 'ID : 10  , Has Been Removed Successfull', '2016-10-06 15:42:50'),
(28, '::1', 5, 'malette', 'save', 'New Data with ID 11 Has been Inserted !', '2016-10-06 15:43:01'),
(29, '::1', 5, 'malette', 'save', 'New Data with ID 12 Has been Inserted !', '2016-10-06 15:43:24'),
(30, '::1', 5, 'malette', 'delete', 'ID : 11  , Has Been Removed Successfull', '2016-10-06 15:46:47'),
(31, '::1', 5, 'malette', 'delete', 'ID : 12  , Has Been Removed Successfull', '2016-10-06 15:46:54'),
(32, '::1', 5, 'malette', 'save', 'Data with ID 6 Has been Updated !', '2016-10-06 15:47:04'),
(33, '::1', 5, 'reseauxsalles', 'save', 'Data with ID 4 Has been Updated !', '2016-10-06 15:50:39'),
(34, '::1', 5, 'complexesportif', 'save', 'Data with ID 1 Has been Updated !', '2016-10-06 15:51:50'),
(35, '::1', 5, 'complexesportif', 'save', 'Data with ID 3 Has been Updated !', '2016-10-06 15:52:09'),
(36, '::1', 5, 'malette', 'save', 'Data with ID 6 Has been Updated !', '2016-10-06 15:57:08'),
(37, '::1', 5, 'capteur', 'save', 'New Data with ID 3 Has been Inserted !', '2016-10-06 16:17:56'),
(38, '::1', 5, 'capteur', 'save', 'Data with ID 3 Has been Updated !', '2016-10-06 16:19:08'),
(39, '::1', 5, 'capteur', 'save', 'New Data with ID 4 Has been Inserted !', '2016-10-06 16:19:57'),
(40, '::1', 5, 'equipe', 'save', 'New Data with ID 5 Has been Inserted !', '2016-10-06 17:05:40'),
(41, '::1', 5, 'complexesportif', 'save', 'Data with ID 2 Has been Updated !', '2016-10-06 17:08:46'),
(42, '::1', 5, 'capteur', 'save', 'New Data with ID 5 Has been Inserted !', '2016-10-06 17:18:00'),
(43, '::1', 5, 'joueur', 'save', 'Data with ID 4 Has been Updated !', '2016-10-07 12:37:12'),
(44, '::1', 5, 'joueur', 'save', 'Data with ID 5 Has been Updated !', '2016-10-07 12:37:26'),
(45, '::1', 5, 'partie', 'save', 'Data with ID 2 Has been Updated !', '2016-10-10 13:07:01'),
(46, '::1', 5, 'partie', 'save', 'Data with ID 3 Has been Updated !', '2016-10-10 13:07:31'),
(47, '::1', 5, 'joueurselectionne', 'save', 'New Data with ID 1 Has been Inserted !', '2016-10-11 12:51:55'),
(48, '::1', 5, 'joueurselectionne', 'save', 'New Data with ID 2 Has been Inserted !', '2016-10-11 12:52:12'),
(49, '::1', 5, 'joueur', 'save', 'New Data with ID 6 Has been Inserted !', '2016-10-11 12:54:18'),
(50, '::1', 5, 'joueur', 'save', 'Data with ID 6 Has been Updated !', '2016-10-11 12:54:54'),
(51, '::1', 5, 'reseauxsalles', 'save', 'Data with ID 3 Has been Updated !', '2016-10-11 13:01:58'),
(52, '::1', 5, 'complexesportif', 'save', 'Data with ID 1 Has been Updated !', '2016-10-11 13:14:43'),
(53, '::1', 5, 'complexesportif', 'save', 'Data with ID 3 Has been Updated !', '2016-10-11 13:16:19'),
(54, '::1', 5, 'salle', 'save', 'Data with ID 1 Has been Updated !', '2016-10-11 13:17:34'),
(55, '::1', 5, 'salle', 'save', 'New Data with ID 2 Has been Inserted !', '2016-10-11 13:17:43'),
(56, '::1', 5, 'salle', 'save', 'New Data with ID 3 Has been Inserted !', '2016-10-11 13:17:52'),
(57, '::1', 5, 'salle', 'save', 'New Data with ID 4 Has been Inserted !', '2016-10-11 13:18:01'),
(58, '::1', 5, 'salle', 'save', 'New Data with ID 5 Has been Inserted !', '2016-10-11 13:18:09'),
(59, '::1', 5, 'salle', 'save', 'New Data with ID 6 Has been Inserted !', '2016-10-11 13:18:18'),
(60, '::1', 5, 'salle', 'save', 'New Data with ID 7 Has been Inserted !', '2016-10-11 13:18:27'),
(61, '::1', 5, 'salle', 'save', 'New Data with ID 8 Has been Inserted !', '2016-10-11 13:18:35'),
(62, '::1', 5, 'salle', 'save', 'New Data with ID 9 Has been Inserted !', '2016-10-11 13:18:46'),
(63, '::1', 5, 'salle', 'save', 'New Data with ID 10 Has been Inserted !', '2016-10-11 13:18:55'),
(64, '::1', 5, 'reseauxsalles', 'delete', 'ID : 1,2  , Has Been Removed Successfull', '2016-10-11 13:21:19'),
(65, '::1', 5, 'complexesportif', 'save', 'New Data with ID 6 Has been Inserted !', '2016-10-11 13:24:08'),
(66, '::1', 5, 'joueurselectionne', 'save', 'New Data with ID 3 Has been Inserted !', '2016-10-11 14:13:59'),
(67, '::1', 5, 'partie', 'save', 'New Data with ID 4 Has been Inserted !', '2016-10-11 14:20:13');
