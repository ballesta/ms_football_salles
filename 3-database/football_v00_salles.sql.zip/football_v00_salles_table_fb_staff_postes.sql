
-- --------------------------------------------------------

--
-- Structure de la table `fb_staff_postes`
--

CREATE TABLE `fb_staff_postes` (
  `staff_poste_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_staff_postes`
--

INSERT INTO `fb_staff_postes` (`staff_poste_id`, `nom`) VALUES
(1, 'Kiné'),
(2, 'Analyste vidéo');
