
-- --------------------------------------------------------

--
-- Structure de la table `fb_equipes`
--

CREATE TABLE `fb_equipes` (
  `equipe_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL,
  `complexe_salle_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_equipes`
--

INSERT INTO `fb_equipes` (`equipe_id`, `nom`, `complexe_salle_id`) VALUES
(1, 'Equipe 1', 1),
(2, 'Equipe 2', 1),
(4, 'Equipe 3', 1),
(5, 'us 2 black hawks', 3);
