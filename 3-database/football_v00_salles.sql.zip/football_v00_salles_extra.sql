
--
-- Index pour les tables exportées
--

--
-- Index pour la table `fbs_complexe_salles`
--
ALTER TABLE `fbs_complexe_salles`
  ADD PRIMARY KEY (`complexe_salle_id`),
  ADD UNIQUE KEY `nom` (`nom`);

--
-- Index pour la table `fbs_reseaux_salles`
--
ALTER TABLE `fbs_reseaux_salles`
  ADD PRIMARY KEY (`club_id`);

--
-- Index pour la table `fbs_salles`
--
ALTER TABLE `fbs_salles`
  ADD PRIMARY KEY (`salle_id`);

--
-- Index pour la table `fb_capteurs`
--
ALTER TABLE `fb_capteurs`
  ADD PRIMARY KEY (`capteur_id`),
  ADD KEY `capteurs_club_id_foreign` (`club_id`);

--
-- Index pour la table `fb_categories`
--
ALTER TABLE `fb_categories`
  ADD PRIMARY KEY (`categorie_id`);

--
-- Index pour la table `fb_clubs`
--
ALTER TABLE `fb_clubs`
  ADD PRIMARY KEY (`club_id`);

--
-- Index pour la table `fb_club_type`
--
ALTER TABLE `fb_club_type`
  ADD PRIMARY KEY (`club_type_id`);

--
-- Index pour la table `fb_entraineurs`
--
ALTER TABLE `fb_entraineurs`
  ADD PRIMARY KEY (`entraineur_id`),
  ADD KEY `entraineurs_club_id_foreign` (`club_id`);

--
-- Index pour la table `fb_equipes`
--
ALTER TABLE `fb_equipes`
  ADD PRIMARY KEY (`equipe_id`);

--
-- Index pour la table `fb_equipe_joueur`
--
ALTER TABLE `fb_equipe_joueur`
  ADD PRIMARY KEY (`equipe_joueur_id`);

--
-- Index pour la table `fb_joueurs`
--
ALTER TABLE `fb_joueurs`
  ADD PRIMARY KEY (`joueur_id`),
  ADD KEY `joueurs_club_id_foreign` (`complexe_salle_id`),
  ADD KEY `joueurs_entraineur_id_foreign` (`entraineur_id`);

--
-- Index pour la table `fb_joueurs_selectionnes`
--
ALTER TABLE `fb_joueurs_selectionnes`
  ADD PRIMARY KEY (`joueur_selectionne_id`);

--
-- Index pour la table `fb_malette_capteurs`
--
ALTER TABLE `fb_malette_capteurs`
  ADD PRIMARY KEY (`malette_capteurs_id`);

--
-- Index pour la table `fb_mesures`
--
ALTER TABLE `fb_mesures`
  ADD PRIMARY KEY (`mesure_id`),
  ADD KEY `mesures_club_id_foreign` (`club_id`),
  ADD KEY `mesures_session_mesure_id_foreign` (`session_mesure_id`);

--
-- Index pour la table `fb_partie`
--
ALTER TABLE `fb_partie`
  ADD PRIMARY KEY (`partie_id`),
  ADD KEY `activites_club_id_foreign` (`salle_id`);

--
-- Index pour la table `fb_password_resets`
--
ALTER TABLE `fb_password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Index pour la table `fb_postes`
--
ALTER TABLE `fb_postes`
  ADD PRIMARY KEY (`poste_id`);

--
-- Index pour la table `fb_sessions_mesures`
--
ALTER TABLE `fb_sessions_mesures`
  ADD PRIMARY KEY (`session_mesure_id`),
  ADD KEY `entraineur_id` (`entraineur_id`),
  ADD KEY `sessions_mesures_club_id_foreign` (`club_id`),
  ADD KEY `sessions_mesures_activite_id_foreign` (`activite_id`),
  ADD KEY `sessions_mesures_capteur_id_foreign` (`capteur_id`),
  ADD KEY `sessions_mesures_joueur_id_foreign` (`joueur_id`);

--
-- Index pour la table `fb_stades`
--
ALTER TABLE `fb_stades`
  ADD PRIMARY KEY (`stade_id`);

--
-- Index pour la table `fb_staff`
--
ALTER TABLE `fb_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Index pour la table `fb_staff_postes`
--
ALTER TABLE `fb_staff_postes`
  ADD PRIMARY KEY (`staff_poste_id`);

--
-- Index pour la table `fb_users`
--
ALTER TABLE `fb_users`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tb_groups`
--
ALTER TABLE `tb_groups`
  ADD PRIMARY KEY (`group_id`);

--
-- Index pour la table `tb_groups_access`
--
ALTER TABLE `tb_groups_access`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tb_logs`
--
ALTER TABLE `tb_logs`
  ADD PRIMARY KEY (`auditID`);

--
-- Index pour la table `tb_menu`
--
ALTER TABLE `tb_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Index pour la table `tb_module`
--
ALTER TABLE `tb_module`
  ADD PRIMARY KEY (`module_id`);

--
-- Index pour la table `tb_notification`
--
ALTER TABLE `tb_notification`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tb_pages`
--
ALTER TABLE `tb_pages`
  ADD PRIMARY KEY (`pageID`);

--
-- Index pour la table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `fbs_complexe_salles`
--
ALTER TABLE `fbs_complexe_salles`
  MODIFY `complexe_salle_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `fbs_reseaux_salles`
--
ALTER TABLE `fbs_reseaux_salles`
  MODIFY `club_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `fbs_salles`
--
ALTER TABLE `fbs_salles`
  MODIFY `salle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `fb_capteurs`
--
ALTER TABLE `fb_capteurs`
  MODIFY `capteur_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `fb_categories`
--
ALTER TABLE `fb_categories`
  MODIFY `categorie_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `fb_clubs`
--
ALTER TABLE `fb_clubs`
  MODIFY `club_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `fb_club_type`
--
ALTER TABLE `fb_club_type`
  MODIFY `club_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `fb_entraineurs`
--
ALTER TABLE `fb_entraineurs`
  MODIFY `entraineur_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `fb_equipes`
--
ALTER TABLE `fb_equipes`
  MODIFY `equipe_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `fb_equipe_joueur`
--
ALTER TABLE `fb_equipe_joueur`
  MODIFY `equipe_joueur_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `fb_joueurs`
--
ALTER TABLE `fb_joueurs`
  MODIFY `joueur_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `fb_joueurs_selectionnes`
--
ALTER TABLE `fb_joueurs_selectionnes`
  MODIFY `joueur_selectionne_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `fb_malette_capteurs`
--
ALTER TABLE `fb_malette_capteurs`
  MODIFY `malette_capteurs_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `fb_mesures`
--
ALTER TABLE `fb_mesures`
  MODIFY `mesure_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `fb_partie`
--
ALTER TABLE `fb_partie`
  MODIFY `partie_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `fb_postes`
--
ALTER TABLE `fb_postes`
  MODIFY `poste_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `fb_sessions_mesures`
--
ALTER TABLE `fb_sessions_mesures`
  MODIFY `session_mesure_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `fb_stades`
--
ALTER TABLE `fb_stades`
  MODIFY `stade_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `fb_staff`
--
ALTER TABLE `fb_staff`
  MODIFY `staff_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `fb_staff_postes`
--
ALTER TABLE `fb_staff_postes`
  MODIFY `staff_poste_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `fb_users`
--
ALTER TABLE `fb_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `tb_groups`
--
ALTER TABLE `tb_groups`
  MODIFY `group_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `tb_groups_access`
--
ALTER TABLE `tb_groups_access`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=505;
--
-- AUTO_INCREMENT pour la table `tb_logs`
--
ALTER TABLE `tb_logs`
  MODIFY `auditID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT pour la table `tb_menu`
--
ALTER TABLE `tb_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT pour la table `tb_module`
--
ALTER TABLE `tb_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT pour la table `tb_notification`
--
ALTER TABLE `tb_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `tb_pages`
--
ALTER TABLE `tb_pages`
  MODIFY `pageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT pour la table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `fb_capteurs`
--
ALTER TABLE `fb_capteurs`
  ADD CONSTRAINT `capteurs_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `fb_clubs` (`club_id`);

--
-- Contraintes pour la table `fb_entraineurs`
--
ALTER TABLE `fb_entraineurs`
  ADD CONSTRAINT `entraineurs_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `fb_clubs` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `fb_joueurs`
--
ALTER TABLE `fb_joueurs`
  ADD CONSTRAINT `joueurs_club_id_foreign` FOREIGN KEY (`complexe_salle_id`) REFERENCES `fb_clubs` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `joueurs_entraineur_id_foreign` FOREIGN KEY (`entraineur_id`) REFERENCES `fb_entraineurs` (`entraineur_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `fb_mesures`
--
ALTER TABLE `fb_mesures`
  ADD CONSTRAINT `mesures_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `fb_clubs` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mesures_session_mesure_id_foreign` FOREIGN KEY (`session_mesure_id`) REFERENCES `fb_sessions_mesures` (`session_mesure_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `fb_partie`
--
ALTER TABLE `fb_partie`
  ADD CONSTRAINT `activites_club_id_foreign` FOREIGN KEY (`salle_id`) REFERENCES `fb_clubs` (`club_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `fb_sessions_mesures`
--
ALTER TABLE `fb_sessions_mesures`
  ADD CONSTRAINT `sessions_mesures_activite_id_foreign` FOREIGN KEY (`activite_id`) REFERENCES `fb_partie` (`partie_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sessions_mesures_capteur_id_foreign` FOREIGN KEY (`capteur_id`) REFERENCES `fb_capteurs` (`capteur_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sessions_mesures_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `fb_clubs` (`club_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sessions_mesures_joueur_id_foreign` FOREIGN KEY (`joueur_id`) REFERENCES `fb_joueurs` (`joueur_id`) ON DELETE CASCADE ON UPDATE CASCADE;
