
-- --------------------------------------------------------

--
-- Structure de la table `fbs_complexe_salles`
--

CREATE TABLE `fbs_complexe_salles` (
  `complexe_salle_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(100) NOT NULL,
  `Adresse` text NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `club_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fbs_complexe_salles`
--

INSERT INTO `fbs_complexe_salles` (`complexe_salle_id`, `nom`, `Adresse`, `code_postal`, `ville`, `telephone`, `email`, `club_id`) VALUES
(1, 'PORTE D\'IVRY', '14 rue Jules Vanzuppe,  Ivry-sur-Seine, France', '94200', 'Ivry-sur-Seine', '01 84 04 01 80', 'ivry@urbansoccer.fr', 3),
(2, 'PSG NNNNNNNNNNNNNN', 'aaaaaaaaaaaaaaa', '1111', 'vvvvvvvvvvvvvvvv', '1111111111', 'bernard@ballesta.fr', 1),
(3, ' ASNIÈRES', '63 rue Henri Vuillemin', '92230 ', 'Gennevilliers', '01 78 14 07 90', 'asnieres@urbansoccer.fr', 3),
(4, 'PSG cccccccccccc', 'cccccccccccccc', '1111', 'vvvvvvvvvvvvv', '111111111111', 'bernard@ballesta.fr', 1),
(6, 'CLERMONT', '46 rue des Varennes', '63170', 'Aubière', '04 73 26 51 89', 'clermont@urbansoccer.fr', 3);
