
-- --------------------------------------------------------

--
-- Structure de la table `fb_staff`
--

CREATE TABLE `fb_staff` (
  `staff_id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL,
  `prenom` varchar(40) NOT NULL,
  `mail` varchar(40) NOT NULL,
  `staff_poste_id` int(10) UNSIGNED NOT NULL,
  `club_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fb_staff`
--

INSERT INTO `fb_staff` (`staff_id`, `nom`, `prenom`, `mail`, `staff_poste_id`, `club_id`) VALUES
(1, 'aaaaaaaaaaaa', 'aaaaaaaaaaaa', 'AAAAAAAA@AAAAAAAAAA.com', 1, 1),
(2, 'Le Rebouteu', 'Yohan', 'XXXX@YYYY.COM', 1, 1);
